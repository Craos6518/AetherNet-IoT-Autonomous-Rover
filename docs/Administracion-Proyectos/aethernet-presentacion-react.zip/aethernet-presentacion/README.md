# AetherNet — Presentación Entrega 1

Presentación interactiva en React + Vite para la sustentación individual de la Entrega 1 de TS683.

## Requisitos

- Node.js 18 o superior
- npm

## Ejecución local

```bash
npm install
npm run dev
```

Abrir la URL indicada por Vite.

## Compilación de producción

```bash
npm run build
npm run preview
```

## Despliegue en Vercel

1. Crear un repositorio en GitHub.
2. Subir el contenido de este proyecto.
3. Importar el repositorio en Vercel.
4. Usar estos valores:
   - Framework Preset: Vite
   - Build Command: `npm run build`
   - Output Directory: `dist`
   - Install Command: `npm install`

Vercel detectará el proyecto automáticamente en la mayoría de los casos.

## Controles

- Flecha derecha / espacio: siguiente diapositiva
- Flecha izquierda: diapositiva anterior
- `N`: mostrar u ocultar notas
- `Q`: mostrar u ocultar preguntas
- `Home`: primera diapositiva
- `End`: última diapositiva

## Observación académica

El contenido es una base de presentación para la sustentación. Antes de exponer, revisa que las formulaciones del problema, objetivos, metodología y alcance coincidan literalmente con la versión final del documento entregado.
