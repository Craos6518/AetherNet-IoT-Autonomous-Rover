import React, { useEffect, useState } from "react";
import { createRoot } from "react-dom/client";
import {
  ArrowLeft,
  ArrowRight,
  CheckCircle2,
  Clock3,
  Cpu,
  ExternalLink,
  GitBranch,
  Layers3,
  Lightbulb,
  ListChecks,
  MessageCircleQuestion,
  Network,
  Play,
  Presentation,
  Rocket,
  Target,
  Timer,
  Workflow
} from "lucide-react";
import "./styles.css";

const slides = [
  {
    kicker: "TS683 · Entrega 1",
    title: "AetherNet",
    subtitle: "IoT & Autonomous Rover",
    description:
      "Planeación inicial de una solución que integra domótica modular, control de acceso y robótica móvil.",
    type: "cover",
    duration: "0:35",
    notes:
      "Presentar el proyecto, identificar el curso y explicar en una frase qué integra AetherNet. Aclarar que esta sustentación se centra en la planeación inicial."
  },
  {
    kicker: "01 · Problema",
    title: "¿Qué problemática se busca abordar?",
    description:
      "El proyecto plantea integrar diferentes capacidades de automatización, control y movilidad en una solución modular.",
    bullets: [
      "Definir una problemática concreta y acotada.",
      "Relacionar el problema con los usuarios y el contexto de uso.",
      "Justificar la pertinencia de una solución que combine IoT y robótica móvil."
    ],
    callout: "La solución se presenta como un proyecto integrador, no como un conjunto aislado de funcionalidades.",
    icon: Lightbulb,
    duration: "0:55",
    notes:
      "Explicar el problema con las palabras del documento. No añadir cifras o afirmaciones que no estén respaldadas por la planeación. Conectar la necesidad con la propuesta de integración."
  },
  {
    kicker: "02 · Objetivos y alcance",
    title: "Qué se desarrollará y qué quedará fuera",
    description:
      "El alcance delimita el trabajo realizable durante el semestre y evita comprometer funcionalidades no planificadas.",
    columns: [
      {
        title: "Objetivos",
        items: [
          "Orientan los resultados esperados.",
          "Se organizan en un objetivo general y objetivos específicos.",
          "Deben poder verificarse mediante evidencias."
        ]
      },
      {
        title: "Alcance",
        items: [
          "Define los componentes incluidos.",
          "Establece exclusiones y restricciones.",
          "Se mantiene alineado con el tiempo disponible."
        ]
      }
    ],
    icon: Target,
    duration: "0:55",
    notes:
      "Explicar el objetivo general y resumir los específicos sin leerlos de forma extensa. Después diferenciar claramente lo incluido de lo excluido."
  },
  {
    kicker: "03 · Metodología",
    title: "Cómo se organizará el desarrollo",
    description:
      "La metodología se aplica mediante iteraciones, entregas parciales, validaciones y evidencias.",
    steps: [
      ["Planificar", "Definir la iteración y sus entregables."],
      ["Construir", "Desarrollar el componente priorizado."],
      ["Validar", "Comprobar funcionamiento y registrar evidencia."],
      ["Ajustar", "Incorporar correcciones al siguiente ciclo."]
    ],
    callout: "La metodología debe explicar cómo se trabajará, no solamente mencionar su nombre.",
    icon: Workflow,
    duration: "0:55",
    notes:
      "Explicar cómo se aplicará la metodología en un proyecto individual. Destacar que las iteraciones permiten controlar el avance y detectar problemas temprano."
  },
  {
    kicker: "04 · WBS",
    title: "El proyecto se divide en siete fases",
    description:
      "La Estructura de Desglose del Trabajo transforma el alcance general en grupos de trabajo controlables.",
    phases: [
      "Gestión y planeación",
      "Infraestructura DevOps",
      "Aplicación AetherControl",
      "Firmware Edge",
      "Automatización LowCode",
      "Estadística y calidad",
      "Documentación y cierre"
    ],
    callout: "Cada paquete debe producir una evidencia verificable: código, pruebas, evidencia de hardware cuando corresponda y documentación actualizada.",
    icon: Layers3,
    duration: "1:10",
    notes:
      "Mostrar las siete fases y explicar que el WBS permite organizar el alcance. No leer cada actividad hoja por hoja; seleccionar dos ejemplos para explicar la lógica del desglose."
  },
  {
    kicker: "05 · Cronograma",
    title: "Una secuencia temporal para ejecutar el trabajo",
    description:
      "El cronograma conecta las actividades del WBS con semanas, responsables, hitos y evidencias.",
    timeline: [
      ["Inicio", "Planeación, definición y preparación de infraestructura"],
      ["Iteraciones", "Construcción progresiva de software, firmware y automatización"],
      ["Integración", "Validación de componentes y resolución de inconsistencias"],
      ["Cierre", "Documentación, evidencias, ajustes y sustentación"]
    ],
    callout: "La planificación contempla 12 semanas, con espacio para las iteraciones y un buffer de cierre.",
    icon: Clock3,
    duration: "1:10",
    notes:
      "Explicar la secuencia y las dependencias principales. Aclarar que el trabajo es individual y que las actividades se organizan secuencialmente, no como si existiera un equipo paralelo."
  },
  {
    kicker: "06 · Trazabilidad",
    title: "De la intención a la evidencia",
    description:
      "La coherencia del proyecto se comprueba conectando cada nivel de la planeación.",
    trace: [
      ["Objetivo", "Qué resultado se pretende alcanzar"],
      ["Alcance", "Qué está incluido y qué no"],
      ["WBS", "En qué paquetes se divide el trabajo"],
      ["Cronograma", "Cuándo y en qué secuencia se ejecuta"],
      ["Evidencia", "Cómo se comprobará el cumplimiento"]
    ],
    icon: Network,
    duration: "0:55",
    notes:
      "Usar esta diapositiva para demostrar dominio. Explicar que un objetivo sin actividad, fecha o evidencia no está completamente aterrizado en la planeación."
  },
  {
    kicker: "07 · Cierre",
    title: "Una planeación controlada para desarrollar AetherNet",
    description:
      "El proyecto se ejecutará con un alcance delimitado, fases identificadas, una secuencia temporal y evidencias de validación.",
    closing: [
      "Problema y propósito definidos.",
      "Objetivos y alcance relacionados.",
      "WBS organizado en siete fases.",
      "Cronograma con iteraciones y buffer de cierre."
    ],
    callout: "Preguntas",
    icon: Rocket,
    duration: "0:40",
    notes:
      "Recapitular los cuatro elementos principales y finalizar invitando a las preguntas. No añadir una demostración técnica extensa salvo que el docente la solicite."
  }
];

const questions = [
  "¿Cuál es el problema concreto que resuelve AetherNet?",
  "¿Por qué el proyecto es viable durante el semestre?",
  "¿Qué componentes quedan fuera del alcance?",
  "¿Por qué se eligió la metodología definida?",
  "¿Qué sucede si una actividad del cronograma se retrasa?",
  "¿Cómo se relaciona el WBS con el cronograma?",
  "¿Cómo se comprobará que cada componente funciona?",
  "¿Cuál es el principal riesgo de planificación?",
  "¿Qué se espera entregar en la primera iteración?",
  "¿Cómo se medirá el cumplimiento de los objetivos?"
];

function App() {
  const [current, setCurrent] = useState(0);
  const [showNotes, setShowNotes] = useState(false);
  const [showQuestions, setShowQuestions] = useState(false);
  const [checked, setChecked] = useState([]);

  const slide = slides[current];
  const Icon = slide.icon || Presentation;

  const go = (direction) => {
    setCurrent((value) => Math.min(slides.length - 1, Math.max(0, value + direction)));
  };

  useEffect(() => {
    const onKeyDown = (event) => {
      if (event.key === "ArrowRight" || event.key === " ") go(1);
      if (event.key === "ArrowLeft") go(-1);
      if (event.key.toLowerCase() === "n") setShowNotes((value) => !value);
      if (event.key.toLowerCase() === "q") setShowQuestions((value) => !value);
      if (event.key === "Home") setCurrent(0);
      if (event.key === "End") setCurrent(slides.length - 1);
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, []);

  return (
    <main className="app-shell">
      <header className="topbar">
        <div className="brand">
          <div className="brand-mark"><Cpu size={18} /></div>
          <div>
            <strong>AetherNet</strong>
            <span>Sustentación · Entrega 1</span>
          </div>
        </div>
        <div className="top-actions">
          <button className="ghost-button" onClick={() => setShowQuestions((value) => !value)}>
            <MessageCircleQuestion size={16} /> Preguntas
          </button>
          <button className="ghost-button" onClick={() => setShowNotes((value) => !value)}>
            <ListChecks size={16} /> Notas
          </button>
        </div>
      </header>

      <section className="presentation-frame">
        <div className="slide-counter">
          <span>{String(current + 1).padStart(2, "0")}</span>
          <span>/ {String(slides.length).padStart(2, "0")}</span>
        </div>

        <div className={`slide ${slide.type === "cover" ? "cover-slide" : ""}`}>
          <div className="ambient ambient-one" />
          <div className="ambient ambient-two" />
          <div className="slide-content">
            <div className="kicker"><span className="kicker-dot" />{slide.kicker}</div>
            <div className="heading-row">
              <div className="heading-block">
                <h1>{slide.title}</h1>
                {slide.subtitle && <h2>{slide.subtitle}</h2>}
                <p className="description">{slide.description}</p>
              </div>
              <div className="icon-orb"><Icon size={34} strokeWidth={1.5} /></div>
            </div>

            {slide.type === "cover" && (
              <div className="cover-lower">
                <div className="cover-tag"><GitBranch size={16} /> Planeación inicial del proyecto</div>
                <div className="cover-meta">
                  <span><Target size={15} /> TS683 Administración y Planeación de Proyectos de Software</span>
                  <span><Presentation size={15} /> Presentación individual</span>
                </div>
              </div>
            )}

            {slide.bullets && (
              <div className="bullet-list">
                {slide.bullets.map((item) => <div className="bullet-item" key={item}><CheckCircle2 size={18} />{item}</div>)}
              </div>
            )}

            {slide.columns && (
              <div className="two-columns">
                {slide.columns.map((column) => (
                  <div className="info-card" key={column.title}>
                    <h3>{column.title}</h3>
                    {column.items.map((item) => <p key={item}><span>•</span>{item}</p>)}
                  </div>
                ))}
              </div>
            )}

            {slide.steps && (
              <div className="step-grid">
                {slide.steps.map(([title, text], index) => (
                  <div className="step-card" key={title}>
                    <span className="step-number">0{index + 1}</span>
                    <h3>{title}</h3>
                    <p>{text}</p>
                  </div>
                ))}
              </div>
            )}

            {slide.phases && (
              <div className="phase-grid">
                {slide.phases.map((phase, index) => (
                  <div className="phase-card" key={phase}>
                    <span>{String(index + 1).padStart(2, "0")}</span>
                    <p>{phase}</p>
                  </div>
                ))}
              </div>
            )}

            {slide.timeline && (
              <div className="timeline">
                {slide.timeline.map(([title, text], index) => (
                  <div className="timeline-row" key={title}>
                    <div className="timeline-marker">{index + 1}</div>
                    <div><h3>{title}</h3><p>{text}</p></div>
                  </div>
                ))}
              </div>
            )}

            {slide.trace && (
              <div className="trace-list">
                {slide.trace.map(([title, text], index) => (
                  <div className="trace-row" key={title}>
                    <span>{index + 1}</span>
                    <strong>{title}</strong>
                    <p>{text}</p>
                  </div>
                ))}
              </div>
            )}

            {slide.closing && (
              <div className="closing-grid">
                {slide.closing.map((item) => <div className="closing-item" key={item}><CheckCircle2 size={18} />{item}</div>)}
              </div>
            )}

            {slide.callout && <div className="callout"><Lightbulb size={18} /><span>{slide.callout}</span></div>}
          </div>
          <div className="slide-footer">
            <span>AetherNet · IoT & Autonomous Rover</span>
            <span><Timer size={14} /> {slide.duration}</span>
          </div>
        </div>

        <div className="controls">
          <button className="control-button" onClick={() => go(-1)} disabled={current === 0}><ArrowLeft size={18} /> Anterior</button>
          <div className="progress-track">
            <div className="progress-value" style={{ width: `${((current + 1) / slides.length) * 100}%` }} />
          </div>
          <button className="control-button primary" onClick={() => go(1)} disabled={current === slides.length - 1}>Siguiente <ArrowRight size={18} /></button>
        </div>
      </section>

      {showNotes && (
        <aside className="panel">
          <div className="panel-heading"><h2>Notas del presentador</h2><span>Diapositiva {current + 1}</span></div>
          <p>{slide.notes}</p>
          <small>Atajos: N para ocultar/mostrar notas · ←/→ para navegar · Inicio/Fin para saltar.</small>
        </aside>
      )}

      {showQuestions && (
        <aside className="panel questions-panel">
          <div className="panel-heading"><h2>Preguntas de preparación</h2><span>{checked.length}/{questions.length}</span></div>
          {questions.map((question, index) => (
            <label className="question-item" key={question}>
              <input
                type="checkbox"
                checked={checked.includes(index)}
                onChange={(event) => setChecked(event.target.checked ? [...checked, index] : checked.filter((item) => item !== index))}
              />
              <span>{question}</span>
            </label>
          ))}
        </aside>
      )}

      <footer className="app-footer">
        <span>Presentación individual · 7–8 minutos objetivo</span>
        <span><ExternalLink size={14} /> Compatible con Vercel</span>
      </footer>
    </main>
  );
}

createRoot(document.getElementById("root")).render(
  <React.StrictMode><App /></React.StrictMode>
);